class User {
  String displayName;
  String email;
  String password;

  User();
}
